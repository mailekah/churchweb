<?php
class JoinBook extends ActiveRecord\Model
{
	static $table_name = 'books';

	static $belongs_to = array();
};
?>